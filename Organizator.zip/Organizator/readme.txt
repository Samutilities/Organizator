Organizator v0.1

Logiciel developpé par SAMEUR Samir

Licence Creative Commons BY-NC-ND 

Plus d'informations:

https://creativecommons.org/licenses/by-nc-nd/4.0/
https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode$

Bonne utilisation ;) !

